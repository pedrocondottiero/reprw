<?php

    for($num=1; $num<=200; $num++) {
    $primo = 1;

    for($i=2; $i<$num; $i++){

    if($num%$i == 0){
            $primo = 0;
                break;
            }

        }

        if($primo == 1){
            echo $num."Número primo";
        }
        else{
            echo $num."Esse número não é primo";
        }
    }

?>